﻿
//for textarea input
var _itextarea = $.extend({}, _ibase, {

    /*
    getO: function (obj) {
        //return obj.html();
        return obj.val();
    },

    setO: function (obj, value) {
        //obj.html(value);
        obj.val(value);
    },
    */

}); //class