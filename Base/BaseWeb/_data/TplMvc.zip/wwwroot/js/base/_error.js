﻿var _error = {

    log: function (msg) {
        console.log(msg);
    },

}; //class